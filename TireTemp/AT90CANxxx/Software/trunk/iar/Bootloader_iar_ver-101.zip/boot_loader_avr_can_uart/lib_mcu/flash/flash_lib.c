/*C**************************************************************************
* $RCSfile: flash_lib.c,v $
*----------------------------------------------------------------------------
* Copyright (c) 2003 Atmel.
*----------------------------------------------------------------------------
* RELEASE:      $Name: can11-bl-uart-can-0_0_8 $
* REVISION:     $Revision: 1.6 $
* FILE_CVSID:   $Id: flash_lib.c,v 1.6 2003/10/02 15:05:27 jberthy Exp $
*----------------------------------------------------------------------------
* PURPOSE:
* This file contains flash driver for the AVR.
*****************************************************************************/

/*_____ I N C L U D E S ____________________________________________________*/
#include "config.h"
#include "flash_lib.h"
#include "flash_drv.h"


#ifndef FLASH_SIZE
#error You must define FLASH_SIZE in bytes in config.h
#endif

#ifdef DEBUG_FLASHWR
Uchar debug_buffer[FLASH_PAGE_SIZE];
  void debug_flash_fill_temp_buffer(Uint16 data16, Uint32 addr)
  {
     *(Uint16*)&debug_buffer[LOW(addr)%FLASH_PAGE_SIZE] = data16;
  }

#endif

/*_____ M A C R O S ________________________________________________________*/

/*_____ D E F I N I T I O N S ______________________________________________*/

/*_____ D E C L A R A T I O N S ____________________________________________*/


/*F**************************************************************************
* NAME: flash_wr_byte
*----------------------------------------------------------------------------
* PARAMS:
* return:   none
*----------------------------------------------------------------------------
* PURPOSE:
*----------------------------------------------------------------------------
* EXAMPLE:
*----------------------------------------------------------------------------
* NOTE:
*----------------------------------------------------------------------------
* REQUIREMENTS:
*****************************************************************************/
void flash_wr_byte(Uint32 addr_byte, Uchar value)
{
  Enable_flash();
  flash_wr_block(&value, addr_byte, 1);
  Disable_flash();
}


/*F**************************************************************************
* NAME: flash_wr_block
*----------------------------------------------------------------------------
* PARAMS:
* return:
*----------------------------------------------------------------------------
* PURPOSE: thid function allows to write up to 256 byte in the on-chip
* flash memory.
*----------------------------------------------------------------------------
* EXAMPLE:
*----------------------------------------------------------------------------
* NOTE: To use this function, the number of byte to write must be odd,
* because this function doesn't manage word alignement.
*----------------------------------------------------------------------------
* REQUIREMENTS:
*****************************************************************************/
Uchar flash_wr_block(Byte _MemType_* src, Uint32 dst, Uchar n)
{
  Uint16 nb_byte, temp16,temp1,temp2;
  Uint32 address, dst_save;;


  if (!n) return (TRUE);
  Enable_flash();
  do
  {
    dst_save = dst;
    if ((dst%FLASH_PAGE_SIZE)==0)//-- if the start address is page aligned
    {
      for (nb_byte=0; (nb_byte<n)&&(nb_byte<FLASH_PAGE_SIZE)&&((nb_byte+2)<=n); nb_byte+=2,src+=2,dst+=2)
      {
        flash_fill_temp_buffer(htons(*(Uint16 *)src),dst);// fill the buffer with data to write
      }
      address=dst;

      if (n&0x01) // if the last byte is not word aligned
      {
        temp1 = (*(Uchar*)src)<<8;
        temp2 = flash_rd_byte((Uchar __FLASHTYPE*)(address+1));
        temp16= temp1+temp2;
        flash_fill_temp_buffer(temp16, dst);
        nb_byte+=2;
        address+=2;
        src++;
      }


      if (n>nb_byte)
      {
        n-=nb_byte;
      }
      else
      {n = 0;}

      for (; nb_byte<FLASH_PAGE_SIZE; nb_byte+=2,address+=2)// fill the buffer with data read from flash
      {
        flash_fill_temp_buffer(flash_rd_word((Uint16 __FLASHTYPE*)address),address);
      }
      Flash_page_erase(dst_save);
      Flash_page_write(dst_save);

    }else{ // the start address is not aligned

      nb_byte = LOW(dst)%FLASH_PAGE_SIZE;
      address = dst-nb_byte;
      for (nb_byte =0; nb_byte<(LOW(dst)%FLASH_PAGE_SIZE)&&((nb_byte+2)<= LOW(dst));nb_byte+=2, address+=2)// fill the buffer with data read from flash
      {
        flash_fill_temp_buffer(flash_rd_word((Uint16 __FLASHTYPE*)address),address);
      }

      if (LOW(dst)&0x01) // if the first byte is not word aligned
      {
        temp16 = flash_rd_byte((Uchar __FLASHTYPE*)address)<<8;
        temp16 |= *(Uchar*) (src);
        flash_fill_temp_buffer(temp16, address);
        nb_byte+=2;
        address+=2;
        src++;
      }

      temp16 = nb_byte;

      for (; (nb_byte<(LOW(dst)+n))&&(nb_byte<FLASH_PAGE_SIZE)&&((nb_byte+2)<=(LOW(dst)+n));nb_byte+=2,src+=2,address+=2)// fill the buffer with data to write
      {
        flash_fill_temp_buffer(htons(*(Uint16 *)src),address);
      }
      if (nb_byte < FLASH_PAGE_SIZE)
      {
        if (((LOW(dst)&0x01)&&!(n&0x01))||(!(LOW(dst)&0x01)&&(n&0x01))) // if the last byte is not word aligned
        {
          temp16 = *(Uchar*) (src)<<8;
          temp16 |= flash_rd_byte((Uchar __FLASHTYPE*)address+1);
          flash_fill_temp_buffer(temp16, address);
          address+=2;
          nb_byte+=2;
        }
      }
      if (n>nb_byte)
      {
        n-=nb_byte;
      }
      else if (nb_byte==FLASH_PAGE_SIZE)// pas sure
      {
        if ((nb_byte%dst)>n){ n =0;}
        else                {n -=(nb_byte%dst);}
        dst +=(nb_byte%dst);
      }else
      {n = 0;}

      for (; nb_byte<FLASH_PAGE_SIZE; nb_byte+=2,address+=2)// fill the buffer with data read from flash
      {
        flash_fill_temp_buffer(flash_rd_word((Uint16 __FLASHTYPE*)address),address);
      }

      Flash_page_erase(dst_save);
      Flash_page_write(dst_save);
    }
  }while(n);
  Disable_flash();
  return TRUE;
}

/****************************************************************************
* NAME: flash_erase
*----------------------------------------------------------------------------
* PARAMS:
* return: none
*----------------------------------------------------------------------------
* PURPOSE:
*----------------------------------------------------------------------------
* EXAMPLE:
*----------------------------------------------------------------------------
* NOTE:
*----------------------------------------------------------------------------
* REQUIREMENTS:
*****************************************************************************/
void flash_erase(void)
{
#if FLASH_SIZE > 0
  Uint32 nb_page;

  Enable_flash();
  nb_page=0;
  do {
    Flash_page_erase(nb_page);
    nb_page += FLASH_PAGE_SIZE;
  } while (nb_page<(FLASH_SIZE-BOOT_SIZE));
  Flash_RWW_Read_enable();
  Disable_flash();
#endif

}

/****************************************************************************
* NAME: flash_rd_byte
*----------------------------------------------------------------------------
* PARAMS:
* return: none
*----------------------------------------------------------------------------
* PURPOSE:
*----------------------------------------------------------------------------
* EXAMPLE:
*----------------------------------------------------------------------------
* NOTE:
*----------------------------------------------------------------------------
* REQUIREMENTS:
*****************************************************************************/
Uchar flash_rd_byte(Uchar __FLASHTYPE* addr)
{
  unsigned char temp;

  Enable_flash();
  temp = *addr;
  Disable_flash();
  return temp;
}
/****************************************************************************
* NAME: flash_rd_word
*----------------------------------------------------------------------------
* PARAMS:
* return: none
*----------------------------------------------------------------------------
* PURPOSE:
*----------------------------------------------------------------------------
* EXAMPLE:
*----------------------------------------------------------------------------
* NOTE:
*----------------------------------------------------------------------------
* REQUIREMENTS:
*****************************************************************************/
Uint16 flash_rd_word(Uint16 __FLASHTYPE* addr)
{
  Union16 temp;

  Enable_flash();
  temp.b[1] = flash_rd_byte ((Uchar __FLASHTYPE*) addr);
  temp.b[0] = flash_rd_byte ((Uchar __FLASHTYPE*)addr+1)
  Disable_flash();

  return temp.w;
}

