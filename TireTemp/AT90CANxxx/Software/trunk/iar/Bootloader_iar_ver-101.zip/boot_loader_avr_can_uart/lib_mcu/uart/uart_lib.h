//**************************************************************************
//! @file $RCSfile: uart_lib.h,v $
//!
//! Copyright (c) 2005 Atmel.
//!
//! Please read file license.txt for copyright notice.
//!
//! @brief This file contains all prototypes and macros of UART lib routines
//!        for all ATMEL CAN devices.
//!
//! @version $Revision: 3.00 $ $Name: jtellier $
//!
//! @todo
//! @bug
//**************************************************************************

#ifndef _UART_LIB_H_
#define _UART_LIB_H_

//_____ I N C L U D E S ____________________________________________________
#include "lib_mcu\uart\uart_drv.h"
#include <stdarg.h>

//_____ D E F I N I T I O N S ______________________________________________
#define DATA_BUF_LEN   12         // Used in uart_mini_printf (max=65535)

//_____ D E C L A R A T I O N S ____________________________________________

//***************************************************************************
//  @fn uart_init
//!
//! UART peripheral initialization. Reset the UART, initialize the uart
//! mode, initialize the baudrate and enable the UART peripheral.
//!
//! @warning If autobaud, only one character is useful. If autobaud, one
//!          16-bit Timer is necessary.
//!
//! @param  Mode (c.f. predefined modes in "uart_drv.h" file)
//!         Baudrate (for fixed baudrate this param is not used)
//!
//! @return Baudrate Status
//!         ==0: research of timing failed
//!         ==1: baudrate performed
//!
extern U8 uart_init (U8 mode, U32 baudrate);

//***************************************************************************
//  @fn uart_test_hit
//!
//! Check if something has been received on the UART peripheral.
//!
//! @warning none
//!
//! @param  none
//!
//! @return Baudrate Status
//!         ==0: Nothing has been received
//!         ==1: A character has been received
//!
extern U8 uart_test_hit (void);

//***************************************************************************
//  @fn uart_putchar
//!
//! Send a character on the UART peripheral.
//!
//! @warning none
//!
//! @param  character to send
//!
//! @return character sent
//!
extern U8 uart_putchar (U8 ch);

//***************************************************************************
//  @fn uart_getchar
//!
//! Get a character from the UART peripheral.
//!
//! @warning none
//!
//! @param  none
//!
//! @return read (received) character on the UART
//!
extern U8 uart_getchar (void);

//***************************************************************************
//  @fn uart_put_string
//!
//! Put a data-string on TX UART. The data-string is send up to null
//! character is found.
//!
//! @warning "uart_init()" must be performed before
//!
//! @param Pointer on U8 data-string
//!
//! @return (none)
//!
//***************************************************************************
void uart_put_string (U8 *data_string);

//***************************************************************************
// Name: uart_mini_printf
// Title: minimal printf with variable argument list
// Description:
//     Write several variables formatted by a format string to a
//     file descriptor.
//     The format string is interpreted like this:
//     any character: output as is
//     %c:  interpret argument as character
//     %s:  interpret argument as pointer to string
//     %d:  interpret argument as decimal (signed) S16
//     %ld: interpret argument as decimal (signed) S32
//     %u:  interpret argument as decimal (unsigned) U16
//     %lu: interpret argument as decimal (unsigned) U32
//     %x:  interpret argument as hex U16 (lower case chars)
//     %lx: interpret argument as hex U32 (lower case chars)
//     %X:  interpret argument as hex U16 (upper case chars)
//     %X:  interpret argument as hex U32 (upper case chars)
//     %%:  print a percent character
// Return: 0=O.K.
//***************************************************************************
U8 uart_mini_printf(U8 *format, ...);


#endif  // _UART_LIB_H_
