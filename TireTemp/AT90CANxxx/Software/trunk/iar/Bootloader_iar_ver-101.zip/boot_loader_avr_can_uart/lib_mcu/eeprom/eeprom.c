/*C**************************************************************************
* $RCSfile: eeprom.c,v $
*----------------------------------------------------------------------------
* Copyright (c) 2003 Atmel.
*----------------------------------------------------------------------------
* RELEASE:      $Name: can11-bl-uart-can-0_0_8 $      
* REVISION:     $Revision: 1.2 $     
* FILE_CVSID:   $Id: eeprom.c,v 1.2 2003/09/08 07:05:29 jberthy Exp $       
*----------------------------------------------------------------------------
* PURPOSE: 
* This file contains C functions to control:
* EEPROM
*****************************************************************************/

/*_____ I N C L U D E S ____________________________________________________*/
#define _EEPROM_C_
#include "config.h"
#include "eeprom.h"

/*_____ M A C R O S ________________________________________________________*/

/*_____ D E F I N I T I O N S ______________________________________________*/
#ifndef EEPROM_SIZE
#error You must define EEPROM_SIZE in bytes in config.h
#else

/*M**************************************************************************
* NAME: eeprom_busy 
*----------------------------------------------------------------------------
* PARAMS:  
*----------------------------------------------------------------------------
* PURPOSE: 
* Gives the status of EEPROM
*****************************************************************************/
#define eeprom_busy()  (EECR &(1<<EEWE))

/*M**************************************************************************
* NAME: eeprom_wr 
*----------------------------------------------------------------------------
* PARAMS:  
* addr: EEPROM address 
* val: Data value to write in the EEPROM.
*----------------------------------------------------------------------------
* PURPOSE: 
* Writes a byte in the EEPROM memory.
*****************************************************************************/
#define eeprom_wr(addr,b) (EEAR=addr, EEDR=b, EECR |= (1<<EEMWE),EECR |= (1<<EEWE))


/*F**************************************************************************
* NAME:eeprom_rd 
*----------------------------------------------------------------------------
* PARAMS:  
* addr: EEPROM address
* return: Byte value read from the EEPROM memory 
*----------------------------------------------------------------------------
* PURPOSE: 
* Reads a byte from the EEPROM memory .
*****************************************************************************/
Byte eeprom_rd(Uint16 addr)
{
  EEAR = addr;
  EECR |= (1<<EERE);
  return(EEDR);
}


/*F**************************************************************************
* NAME: eeprom_erase 
*----------------------------------------------------------------------------
* PARAMS:  
* return: none
*----------------------------------------------------------------------------
* PURPOSE: 
* Erases the entire EEPROM memory. 
*****************************************************************************/
bit eeprom_erase(void)
{
#if EEPROM_SIZE > 0
register Uint16 addr;

Enable_eeprom();
addr=0;
do {
  while (eeprom_busy());
  eeprom_wr(addr,EEPROM_BLANK_VALUE);
  } while (addr++!=(EEPROM_SIZE-1));
Disable_eeprom();
#endif
return TRUE;
}

/*F**************************************************************************
* NAME: eeprom_wr_byte
*----------------------------------------------------------------------------
* PARAMS:  
* addr: EEPROM address 
* val: Data value to write in the EEPROM.
*----------------------------------------------------------------------------
* PURPOSE: 
* Programs one byte in the EEPROM memory.
*****************************************************************************/
bit eeprom_wr_byte (Uint16 addr, Uchar value)
{
Enable_eeprom();
while (eeprom_busy());
eeprom_wr(addr,value);
Disable_eeprom();
return TRUE;
} 


/*F**************************************************************************
* NAME: eeprom_rd_byte
*----------------------------------------------------------------------------
* PARAMS:  
* addr: EEPROM address 
* return: Byte value read from the EEPROM memory 
*----------------------------------------------------------------------------
* PURPOSE: 
* Read one byte on the EEPROM memory.
*****************************************************************************/
Uint16 eeprom_rd_byte (Uint16 addr)
{
register Byte b;
  while (eeprom_busy());
Enable_eeprom();
b=eeprom_rd(addr);
Disable_eeprom();
return b;
} 


/*F**************************************************************************
* NAME: eeprom_rd_block
*----------------------------------------------------------------------------
* PARAMS: 
* src:  Source address, where is the block to read  
* dest: Destination address, where to store data read
* n:    Number of bytes to read
* return: none
*----------------------------------------------------------------------------
* PURPOSE:
* Read a block into external EEPROM
*****************************************************************************/
bit eeprom_rd_block (Uint16 src, Byte _MemType_* dest, Byte n)
{
  while (eeprom_busy());
Enable_eeprom();
for (;n--;++src) *dest++=eeprom_rd(src);
Disable_eeprom();
return TRUE;
}


/*F**************************************************************************
* NAME: eeprom_wr_block
*----------------------------------------------------------------------------
* PARAMS: 
* src:  Source address, where is the block to write
* dest: Destination address, where to write
* n:    Number of bytes to write
* return: none
*----------------------------------------------------------------------------
* PURPOSE:
* Write a page into external EEPROM
*****************************************************************************/
bit eeprom_wr_block (Byte _MemType_* src, Uint16 dest, Byte n)
{
#if EEPROM_SIZE > 0

Enable_eeprom();
for (;n--;)
  {
  while (eeprom_busy());
  eeprom_wr(dest,*src++);
  if (dest++==(EEPROM_SIZE-1)) break; // page not aligned on boundary EEPROM memory block
  } 
Disable_eeprom();
#endif
return TRUE;
}

#endif

