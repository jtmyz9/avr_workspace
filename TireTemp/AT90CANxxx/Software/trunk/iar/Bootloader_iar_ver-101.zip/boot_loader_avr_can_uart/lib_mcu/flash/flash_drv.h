/*H**************************************************************************
* $RCSfile: flash_drv.h,v $         
*----------------------------------------------------------------------------
* Copyright (c) 2003 Atmel.
*----------------------------------------------------------------------------
* RELEASE:      $Name: can11-bl-uart-can-0_0_8 $      
* REVISION:     $Revision: 1.3 $     
* FILE_CVSID:   $Id: flash_drv.h,v 1.3 2003/09/30 15:16:10 jberthy Exp $       
*----------------------------------------------------------------------------
* PURPOSE: 
*****************************************************************************/
#ifndef FLASH_DRV_H
#define FLASH_DRV_H

/*_____ I N C L U D E S ____________________________________________________*/

#include "config.h"

/*_____ M A C R O S ________________________________________________________*/
#define Flash_RWW_Read_enable()   (flash_prg_page(0x00,(1<<RWWSRE)+(1<<SPMEN)))

#define Flash_page_erase(address) (flash_prg_page(address,(1<<PGERS) + (1<<SPMEN)))              

#define Flash_page_write(address)  (flash_prg_page(address,(1<<PGWRT) + (1<<SPMEN)),Flash_RWW_Read_enable())

/*_____ D E C L A R A T I O N S ____________________________________________*/

void flash_prg_page (unsigned long adr, unsigned char function);
void lock_wr_bits (unsigned char val);
void flash_fill_temp_buffer (unsigned int data,unsigned int adr);

#endif  /* FLASH_DRV_H */



