/*H**************************************************************************
* $RCSfile: eeprom.h,v $         
*----------------------------------------------------------------------------
* Copyright (c) 2003 Atmel.
*----------------------------------------------------------------------------
* RELEASE:      $Name: can11-bl-uart-can-0_0_8 $      
* REVISION:     $Revision: 1.2 $     
* FILE_CVSID:   $Id: eeprom.h,v 1.2 2003/09/08 07:05:29 jberthy Exp $       
*----------------------------------------------------------------------------
* PURPOSE: 
* Include file for EEPROM API
*****************************************************************************/
#ifndef _EEPROM_H
#define _EEPROM_H

/*_____ I N C L U D E S ____________________________________________________*/

/*_____ M A C R O S ________________________________________________________*/

/*_____ D E F I N I T I O N S ______________________________________________*/
#define EEPROM_BLANK_VALUE    0xFF

/*_____ D E C L A R A T I O N S ____________________________________________*/
bit     eeprom_erase          (void);
bit     eeprom_wr_byte        (Uint16 addr, Uchar value);
Uint16  eeprom_rd_byte        (Uint16 addr);

bit     eeprom_rd_block       (Uint16 src, Byte _MemType_* dest, Byte n);
bit     eeprom_wr_block       (Byte _MemType_* src, Uint16 dest, Byte n);

#endif  /* _EEPROM_H */

