extern void ASM_CAN_AUTOBAUD(void);

