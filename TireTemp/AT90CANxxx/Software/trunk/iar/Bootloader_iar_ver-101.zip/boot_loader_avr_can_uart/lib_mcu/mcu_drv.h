/*H**************************************************************************
* $RCSfile: mcu_drv.h,v $         
*----------------------------------------------------------------------------
* Copyright (c) 2002 Atmel.
*----------------------------------------------------------------------------
* RELEASE:      $Name: can11-bl-uart-can-0_0_8 $      
* REVISION:     $Revision: 1.7.4.2 $     
* FILE_CVSID:   $Id: mcu_drv.h,v 1.7.4.2 2003/09/26 07:55:27 jberthy Exp $       
*----------------------------------------------------------------------------
* PURPOSE:
* This file contains the C51 driver definition
*****************************************************************************/

#ifndef _AVR_DRV_H_
#define _AVR_DRV_H_

/*_____ I N C L U D E S ____________________________________________________*/


/*_____ M A C R O S ________________________________________________________*/


/*_____ D E F I N I T I O N ________________________________________________*/
#define MSK_UART_5BIT           0x00 /* UCSRnC register */
#define MSK_UART_6BIT           0x02
#define MSK_UART_7BIT           0x04
#define MSK_UART_8BIT           0x06
#define MSK_UART_9BIT           0x06

#define MSK_UART_RX_DONE        0x80 /* UCSRnA register */
#define MSK_UART_TX_COMPLET     0x40
#define MSK_UART_DRE            0x20

#define MSK_UART_ENABLE_RX      0x10 /* UCSRnB register */
#define MSK_UART_ENABLE_TX      0x08 
#define MSK_UART_TX_BIT9        0x01
#define MSK_UART_RX_BIT9        0x02

/*_____ D E C L A R A T I O N ______________________________________________*/
#ifdef USE_UART1
    #define UCSRC    (UCSR0C)
    #define UCSRB    (UCSR0B)
    #define UCSRA    (UCSR0A)
    #define UDR      (UDR0)
    #define UBRRL    (UBRR0L)                   
    #define UBRRH    (UBRR0H)
    
#endif  
#ifdef USE_UART2
    #define UCSRC    (UCSR1C)
    #define UCSRB    (UCSR1B)
    #define UCSRA    (UCSR1A)
    #define UDR      (UDR1)
    #define UBRRL    (UBRR1L)                   
    #define UBRRH    (UBRR1H)

#endif


#define Uart_hw_init(config)    (UCSRC=config)   
//#define Uart_set_baudrate(bdr) defined in /lib_mcu/uart/uart_bdr.h
#define Uart_enable()           (UCSRB|=MSK_UART_ENABLE_RX|MSK_UART_ENABLE_TX)
#define Uart_tx_ready()         ((UCSRA&MSK_UART_DRE))
#define Uart_set_tx_busy()      
#define Uart_send_byte(ch)      (UDR=ch)
#define Uart_rx_ready()         ((UCSRA&MSK_UART_RX_DONE))
#define Uart_get_byte()         (UDR)
#define Uart_ack_rx_byte()      

#endif  /* _AVR_DRV_H_ */

