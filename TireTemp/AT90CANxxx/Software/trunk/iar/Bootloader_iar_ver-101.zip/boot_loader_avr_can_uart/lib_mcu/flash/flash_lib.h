/*H**************************************************************************
* $RCSfile: flash_lib.h,v $
*----------------------------------------------------------------------------
* Copyright (c) 2003 Atmel.
*----------------------------------------------------------------------------
* RELEASE:      $Name: can11-bl-uart-can-0_0_8 $
* REVISION:     $Revision: 1.3 $
* FILE_CVSID:   $Id: flash_lib.h,v 1.3 2003/09/26 07:48:44 jberthy Exp $
*----------------------------------------------------------------------------
* PURPOSE:
* This file is a template for writing C software programs.
* This template file can be parsed by langdoc for automatic documentation
* generation.
*****************************************************************************/
#ifndef FLASH_LIB_H
#define FLASH_LIB_H


/*_____ I N C L U D E S ____________________________________________________*/

#include "config.h"

/*_____ M A C R O S ________________________________________________________*/

/*_____ D E F I N I T I O N S ______________________________________________*/
#define FLASH_BLANK_VALUE   0xFF


/*_____ D E C L A R A T I O N S ____________________________________________*/

extern void flash_wr_byte(Uint32 addr_byte, Uchar value);
extern Uchar flash_wr_block(Byte _MemType_* src, Uint32 dst, Uchar n);
extern void flash_erase(void);
extern Uchar flash_rd_byte(Uchar __FLASHTYPE* addr);
extern Uint16 flash_rd_word(Uint16 __FLASHTYPE* addr);

#endif  /* FLASH_LIB_H */














