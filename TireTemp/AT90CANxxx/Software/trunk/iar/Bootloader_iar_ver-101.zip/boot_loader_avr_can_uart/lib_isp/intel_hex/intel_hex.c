/*C**************************************************************************
* $RCSfile: intel_hex.c,v $
*----------------------------------------------------------------------------
* Copyright (c) 2003 Atmel.
*----------------------------------------------------------------------------
* RELEASE:      $Name: c51rr2-bl-uart-0_0_1 $
* REVISION:     $Revision: 1.22.2.1 $
* FILE_CVSID:   $Id: intel_hex.c,v 1.22.2.1 2005/02/28 15:00:00 ybricard Exp $
*----------------------------------------------------------------------------
* PURPOSE:
*****************************************************************************/

/*_____ I N C L U D E - F I L E S ____________________________________________*/
#define _INTEL_HEX_C_
#include "config.h"
#include "intel_hex.h"
#include "lib_isp/interface.h"


/*_____ G L O B A L S ________________________________________________________*/
//extern xdata Uchar buffer[GLOBAL_BUFFER_SIZE]; //for debug purpose
extern  Uchar buffer[GLOBAL_BUFFER_SIZE];


/*_____ P U B L I C - F U N C T I O N S ______________________________________*/

/*_____ P R I V A T E ________________________________________________________*/
Uchar               state_protocol;
Uchar 	 *  pt_data;          //_MemType_
Uchar               checksum;

/*_____ L O C A L S __________________________________________________________*/

/*_____ P U B L I C - F U N C T I O N S ______________________________________*/

/*_____ P R I V A T E - F U N C T I O N S ____________________________________*/
void    send_cr_lf          (void);
void    send_byte_ascii     (unsigned char);
char    bin_to_ascii        (unsigned char b);
Uchar   ascii_to_bin        (unsigned char);
void    send_info           (char ch);
void    hex_isp_task        (void);


/*F**************************************************************************
* NAME: template_function_1
*----------------------------------------------------------------------------
* PARAMS:
* return:   none
*----------------------------------------------------------------------------
* PURPOSE:
* Init Nerwork frame processing task (intel HEX format)
*****************************************************************************/
void intel_hex_init (void)
{
state_protocol = PROTOC_WAIT_START;
}

/*F**************************************************************************
* NAME: intel_hex
*----------------------------------------------------------------------------
* PARAMS:
* return:   none
*----------------------------------------------------------------------------
* PURPOSE:
* Nerwork frame processing (intel HEX format)
*****************************************************************************/
void intel_hex (void)
{
Byte        data_to_tx;
Uchar       octet_received;

while (test_hit() || state_protocol != PROTOC_WAIT_START)
  {
  data_to_tx = _getkey();
  putchar(data_to_tx);  /* echo */
  if (state_protocol==PROTOC_WAIT_START)
    {
    if (data_to_tx == HEX_RECORD_MARK)
      {
      checksum=0;
      pt_data=&buffer[INDEX_LEN];
      state_protocol++;
      }
    }
  else
    {
    octet_received = ascii_to_bin(data_to_tx) << 4;
    data_to_tx=_getkey();
    putchar(data_to_tx);  /* echo */
    octet_received+= ascii_to_bin(data_to_tx); // = parser_rx()
    checksum+=octet_received;
    if (state_protocol<PROTOC_CHECKSUM)
      {
      *pt_data++=octet_received;
      if (pt_data<&buffer[INDEX_DATA]) state_protocol++;
      if (pt_data >=&buffer[GLOBAL_BUFFER_SIZE] ||
          pt_data >=&buffer[INDEX_DATA+buffer[INDEX_LEN]])
          state_protocol = PROTOC_CHECKSUM;
      }
    else if (state_protocol==PROTOC_CHECKSUM)
      {
      state_protocol = PROTOC_WAIT_START;
      if (!checksum) hex_isp_task(); // checksum(data+checksum)=0 if ok, != 0 if not ok
      else send_info('X'); // bad checksum
      }
    }
  }
}



/*F**************************************************************************
* NAME: send_cr_lf
*----------------------------------------------------------------------------
* PARAMS:
* return:   none
*----------------------------------------------------------------------------
* PURPOSE:
*****************************************************************************/
void send_cr_lf (void)
{
putchar('\r'); // 0x0D; // CR
putchar('\n'); // 0x0A; // LF
}


/*F**************************************************************************
* NAME: send_byte_ascii
*----------------------------------------------------------------------------
* PARAMS:
* return:   none
*----------------------------------------------------------------------------
* PURPOSE:
*****************************************************************************/
void send_byte_ascii (unsigned char byte_to_tx)
{
putchar(bin_to_ascii( byte_to_tx >> 4));
putchar(bin_to_ascii( byte_to_tx & 0x0F));
}



/*F**************************************************************************
* NAME: send_info
*----------------------------------------------------------------------------
* PARAMS:
* return:   none
*----------------------------------------------------------------------------
* PURPOSE:
* error SSB = 'S'
*****************************************************************************/
void send_info(char ch)
{
putchar(ch);
send_cr_lf();
}


//!F**************************************************************************
//! NAME: ascii_to_bin
//!----------------------------------------------------------------------------
//! PARAMS:
//! b: hex digit character
//! return: binary digit to convert
//!----------------------------------------------------------------------------
//! PURPOSE:
//! Convert a binary digit (number) in hex digit character.
//!----------------------------------------------------------------------------
//! EXAMPLE:
//! ascii_to_bin('5') == 5
//! ascii_to_bin('B') == 11
//! ascii_to_bin('b') == 11
//!----------------------------------------------------------------------------
//! NOTE:
//! use macro ?
//!****************************************************************************
unsigned char ascii_to_bin (unsigned char b)
{
b|='a'-'A'; // to_lower: '0'=>'0', 'A'=>'a', 'a'=>'a'
return ( (b <= '9') ? (b-'0') : (b+10-'a') );
}





/*F**************************************************************************
* NAME: bin_to_ascii
*----------------------------------------------------------------------------
* PARAMS:
* b: binary digit to convert
* return:   hex digit character
*----------------------------------------------------------------------------
* PURPOSE:
* Convert a binary digit (number) in hex digit character.
*----------------------------------------------------------------------------
* EXAMPLE:
* bin_to_ascii(5)  == '5'
* bin_to_ascii(11) == 'B'
*----------------------------------------------------------------------------
* NOTE:
* use macro ?
*****************************************************************************/
char bin_to_ascii (unsigned char b)
{
return ( (b <= 0x09) ? (b+'0') : (b+'A'-10) );
}

/*F**************************************************************************
* NAME: hex_isp_task
*----------------------------------------------------------------------------
* PARAMS:
* return:   none
*----------------------------------------------------------------------------
* PURPOSE:
* Execute HEX file commands/bootloader commands.
*----------------------------------------------------------------------------
* NOTE:
* Ready for scheduler
*****************************************************************************/
void hex_isp_task(void)
{
Byte  return_data;          //!protocol return value (Protection / command OK, command FAIL...)

Uint32   l_address;            //!current addresse pointer
Uint32   l_ad_stop;
Uint16   l_data;               //!local data for display
Uint8    nb_byte;
Uchar    _MemType_*  ptr;

Union32         union32;

  return_data='.';     //status OK

  switch (buffer[INDEX_TYPE])
  {
    //!RECORD TYPE : 0x00
    case  BL_WRITE_ID:
      ptr = &buffer[INDEX_DATA];
      if (!isp_write_block( ptr,                                             //! source @
                            ntohs(*(Uint16*)&buffer[INDEX_OFFSET_HIGH]),     //! dest @
                            buffer[INDEX_LEN]))                              //! number if bytes
                            return_data='P';                                 //! Write Security Set
      break;

    //!RECORD TYPE : 0x01
    case BL_START_APP_ID:
      isp_reset(0);
      break;

    //!RECORD TYPE : 0x02
    case BL_SELECT_PAGE_ID:
      isp_select_page  (buffer[INDEX_DATA]>>4);
      break;

    //!RECORD TYPE : 0x03
    case BL_APPLI_MODE_ID:
      if (buffer[INDEX_DATA]==BL_APPLI_MODE_SUB_ID1)
      {
        isp_reset(buffer[INDEX_DATA+1]);
      }
      break;


    //!RECORD TYPE : 0x04
    case BL_SELECT_MEMORY_ID:
      //!BL_READ_ID:
      //!BL_BLANK_CHECK_ID:
      //!BL_ERASE_ID:
      switch (buffer[INDEX_LEN])
      {
        //!RECORD LENGTH : 0x02
        case BL_SELECT_MEMORY_SUB_ID1:
          isp_select_memory(buffer[INDEX_DATA  ]);
          isp_select_page  (buffer[INDEX_DATA+1]);
          break;

        //!RECORD LENGTH : 0x05
        case BL_READ_SUB_ID1:
          //!BBL_READ_SUB_ID2:
          //!BL_BLANK_CHECK_SUB_ID1:
          switch (buffer[INDEX_DATA + 4])
          {
            case BL_READ_SUB_ID2:
              l_address  = ntohs(*(Uint16*)&buffer[INDEX_DATA    ]);
              l_ad_stop  = ntohs(*(Uint16*)&buffer[INDEX_DATA + 2]);
              l_data  =  (Uint16)isp_read(l_address) ;
              if(SECUR16 == l_data)
              {
                putchar('L');
	        send_cr_lf();
                return;
                break;
              }

              while (l_address <= l_ad_stop)
              {
              //!loop on HEX_SIZE_DISP_PAGE
                    send_cr_lf();														//first address read on new line
                    send_byte_ascii(l_address>>8);					//first address
                    send_byte_ascii(l_address);
                    putchar('=');
                    nb_byte = 0;
                    while ((nb_byte < HEX_SIZE_DISP_PAGE) && (l_address <= l_ad_stop) )
                    {
                      send_byte_ascii ((Uint8)l_data);          //!send read char
                      l_address++;
                      nb_byte++;
                      l_data  =  (Uint16)isp_read(l_address) ;
                    }
              }
              send_cr_lf();
              return;
	      break;

            case BL_BLANK_CHECK_SUB_ID2:
              l_address  = ntohs(*(Uint16*)&buffer[INDEX_DATA    ]);
              l_ad_stop  = ntohs(*(Uint16*)&buffer[INDEX_DATA + 2]);
              union32.dw = isp_blank_check(l_address,l_ad_stop);
              if (MSB0(union32))
              {
                send_byte_ascii (MSB2(union32));
                send_byte_ascii (MSB3(union32));
                send_cr_lf();
                return;
              }
              break;


            case BL_ERASE_SUB_ID2:
              isp_erase(0);
              break;
          }
      }
    default :
      break;
  }

  send_info(return_data);
}


