/*C**************************************************************************
* $RCSfile: can_protocol.c,v $
*----------------------------------------------------------------------------
* Copyright (c) 2003 Atmel.
*----------------------------------------------------------------------------
* RELEASE:      $Name: can11-bl-uart-can-0_0_8 $
* REVISION:     $Revision: 1.11 $
* FILE_CVSID:   $Id: can_protocol.c,v 1.11 2003/10/29 10:15:31 jberthy Exp $
*----------------------------------------------------------------------------
* PURPOSE:
* This file contains the managment of the CAN ISP protocol
*****************************************************************************/

/*_____ I N C L U D E S ____________________________________________________*/
#include "config.h"
#include "lib_mcu/can/can_lib.h"
#include "lib_mcu/can/can_autobaud.h"
#include "can_protocol.h"
#include "lib_isp/interface.h"

/*_____ G L O B A L S ________________________________________________________*/

/*_____ P R I V A T E - F U N C T I O N S - D E C L A R A T I O N ____________*/


/*_____ L O C A L S __________________________________________________________*/

/*_____ P U B L I C - F U N C T I O N S ______________________________________*/
Uchar can_ctrl;
Uchar can_tx[NB_DATA_MAX];


can_data_t can_data;
can_msg_t can_msg;


Uchar f_timing_ok;
Uchar f_communication_open;
Uchar f_frame_to_send;
Uchar f_start_from_appli;


/*_____ P R I V A T E - F U N C T I O N S ____________________________________*/
void send_error_security (void);
Uchar can_write_data(void);
void can_display_data(void);
void can_init_write_data(void);
void can_init_display_data(void);

Uchar can_start_appli_ready;
Uchar start_appli_type;

Uint32  nb_byte_to_write;
Uint32  nb_byte_to_read;
Uchar   pt_buffer;
Uint16 	offset_id_copy;
Uchar 	nnb_copy, eb_copy;



/*F**************************************************************************
* NAME: can_init_from_appli
*----------------------------------------------------------------------------
* PARAMS:
* return:   none
*----------------------------------------------------------------------------
* PURPOSE:
*----------------------------------------------------------------------------
* EXAMPLE:
*----------------------------------------------------------------------------
* NOTE:
*----------------------------------------------------------------------------
* REQUIREMENTS:
*****************************************************************************/
void can_init_from_appli(void)
{
  f_start_from_appli = 1;

  offset_id_copy = (CRIS<< 4);
	if (offset_id_copy > MAX_OFFSET_ID)
	{
		offset_id_copy = 0;
	}
	nnb_copy = NNB;
  eb_copy  = EB;

  CAN_CONTROLLER_RESET;
  RazAllMailbox();

// Coonfigure the Channel _0 as receiver
  can_rx_filt.std = (offset_id_copy);
  can_rx_msk.std  = 0x3F0;
  conf_rx         = CONF_NOIDE|CONF_NOBUFFER; // regular reception of standard frame
  CAN_SET_CHANNEL(CHANNEL_0);
  ConfChannel_Rx();

}

/*F**************************************************************************
* NAME: can_init_from_reset
*----------------------------------------------------------------------------
* PARAMS:
* return:   none
*----------------------------------------------------------------------------
* PURPOSE:
*----------------------------------------------------------------------------
* EXAMPLE:
*----------------------------------------------------------------------------
* NOTE:
*----------------------------------------------------------------------------
* REQUIREMENTS:
*****************************************************************************/
void can_init_from_reset(void)
{
    f_start_from_appli = 0;
	
    offset_id_copy = (CRIS<< 4);
    if (offset_id_copy > MAX_OFFSET_ID)
    {
        offset_id_copy = 0;
    }
    nnb_copy = NNB;
    eb_copy = EB;

    CAN_CONTROLLER_RESET;
    RazAllMailbox();
// Coonfigure the Channel _0 as receiver
    can_rx_filt.std = (offset_id_copy);
    can_rx_msk.std  = 0x3F0;
    conf_rx         = CONF_NOIDE|CONF_NOBUFFER; // regular reception of standard frame
    CAN_SET_CHANNEL(CHANNEL_0);
    ConfChannel_Rx();

// Reading of Bit timing
//----------------------
    if (eb_copy != 0xFF)
    {
        CANBT1 = BTC1;
        CANBT2 = BTC2;
        CANBT3 = BTC3;
        CAN_CONTROLLER_ENABLE;
        f_timing_ok = 0;
    }
    PORTD = 0xFF;
}



/*F**************************************************************************
* NAME: can_protocol_task_init
*----------------------------------------------------------------------------
* PARAMS:
* return:   none
*----------------------------------------------------------------------------
* PURPOSE:
* This function initializes the CAN controller and the CAN state machines
*----------------------------------------------------------------------------
* EXAMPLE:
*----------------------------------------------------------------------------
* NOTE:
*----------------------------------------------------------------------------
* REQUIREMENTS:
*****************************************************************************/
void can_protocol_task_init (void)
{
    f_communication_open = 0;
    f_frame_to_send = 0;
    can_start_appli_ready = FALSE;

    pt_st_can_rx = &can_msg;
    can_msg.pt_donne = can_data;

// New config CAN
//---------------------------------------------------------------------
    can_msg.id.std = 0x00;

    if (!f_start_from_appli)
    {
#ifndef DEBUG_BYPASSAUTOBAUD
        if  ((eb_copy ==0xFF)||
            ((eb_copy!= 0xFF)&&((CANBT1==0xFF) ||(CANBT2 == 0xFF)||(CANBT3 == 0xFF))))
        {
            ASM_CAN_AUTOBAUD();
            CAN_AUTOBAUD_DISABLE;
            f_timing_ok = 1;
        }
#else
        CANBT1 = 0x06;
        CANBT2 = 0x0C;
        CANBT3 = 0x5A;
        CAN_CONTROLLER_ENABLE;
#endif
    }
}

/*F**************************************************************************
* NAME: can_protocol_task
*----------------------------------------------------------------------------
* PARAMS:
* return:   none
*----------------------------------------------------------------------------
* PURPOSE:
* This function manage the CAN protocol
*----------------------------------------------------------------------------
* EXAMPLE:
*----------------------------------------------------------------------------
* NOTE:
*----------------------------------------------------------------------------
* REQUIREMENTS:
*****************************************************************************/
void can_protocol_task (void)
{
  Union32 union32;
  static bit restore_default_memspace;

  if (can_start_appli_ready)
  {
    can_start_appli_ready = FALSE;
    if (!isp_reset(start_appli_type)) /*Security error !*/;
  }
  if (restore_default_memspace)
    {
    restore_default_memspace=FALSE;
    isp_select_memory(MEM_DEFAULT);
    }

/************** ERROR MANAGEMENT ********************/
/****************************************************/
	if((CANREC)&&(!f_timing_ok))
	{
		f_timing_ok = 1;
		ASM_CAN_AUTOBAUD();
		CAN_AUTOBAUD_DISABLE; /* End of listening mode */
 	}

/************** RECEPTION MANAGEMENT ********************/
/********************************************************/
  CAN_SET_CHANNEL(CHANNEL_0);

  if (MOB_STATUS)
  {
 // if Message received
    if (CAN_MSG_RECEIVED)
    {
      ReadCanMsg(CHANNEL_RX_ENABLE);
      f_timing_ok = 1;

      switch ((can_msg.id.std - offset_id_copy))
      {
        case CAN_ID_CHANGE_BASE_ADDR:
        {
          if (f_communication_open)
          {
            send_error_security();
            if (can_data[0]&0x02)
            {
	       isp_select_memory(can_data[1]);
	    }
            if (can_data[0]&0x01)
            {
              isp_select_page(can_data[2]);
            }
	  }
          break;
        }

        case CAN_ID_PROG_START:
        {
          if (f_communication_open)
          {
            f_frame_to_send = 1;
            can_ctrl = 0x00;
            can_init_write_data();
            if (can_data[0]==0x80)        // Erase selected memory
            {
//------------ Begin Old protocole
              #ifndef USE_RCS_CAN_PROTOCOL
              label_isp_erase:
              #endif // USE_RCS_CAN_PROTOCOL
//------------ End Old protocol
              if(!isp_erase(can_data[1]<<8 | can_data[2]))
              {
                send_error_security();
              }
              else
              {
                can_ctrl = 0x01;
                can_tx[0] = 0x00;
              }
            }
//---------- Begin Old protocole
            #ifndef USE_RCS_CAN_PROTOCOL
            else if (can_data[0]==1)  	// Init Eeprom memory
            {
              isp_select_memory(MEM_EEPROM);
            }
            #endif // USE_RCS_CAN_PROTOCOL
//---------- End Old protocol
          } // end of "if (f_communication_open)"
          break;
        }

        case CAN_ID_PROG_DATA:
        {
          if (f_communication_open)
          {
            f_frame_to_send = 1;
            can_ctrl = 0x01;
            can_tx[0] = can_write_data();
            if (can_tx[0] == COMMAND_SECURITY)
            {
              send_error_security();
            }
          }
          break;
        }

        case CAN_ID_DISPLAY_DATA:
        {
          if (f_communication_open)
          {
            if (can_data[0] == 0x00)
            {
              can_init_display_data();
              can_display_data();
            }
            else if (can_data[0] == 0x80)
            {
              can_init_display_data();
              union32.dw = isp_blank_check(address,end_address);
              if (MSB0(union32)) // Blank check failed
              {
                *(Uint16*)&can_tx[0] = htons(union32.w[0]);
                can_ctrl = 0x02;
              }
              else
              {
                can_ctrl = 0x00;
              }
              f_frame_to_send = 1;
            }
//---------- Begin old protocole
            #ifndef USE_RCS_CAN_PROTOCOL
            else if (can_data[0] == 0x01)
            {
              isp_select_memory(MEM_FLASH);
              can_init_display_data();
              union32.dw = isp_blank_check(address,end_address);
              if (MSB0(union32))   // Blank check failed
              {
                *(Uint16*)&can_tx[0] = htons(union32.w[0]);
               can_ctrl = 0x02;
              }
              else
              {
                can_ctrl = 0x00;
              }
              f_frame_to_send = 1;
            }
            else if (can_data[0] == 0x02)
            {
              restore_default_memspace=TRUE;
              isp_select_memory(MEM_EEPROM);
              can_init_display_data();
              can_display_data();
            }
            #endif // USE_RCS_CAN_PROTOCOL
//---------- End old protocole
          } // end of "if (f_communication_open)"
          break;
        }

        case CAN_ID_SELECT_NODE:
        {
          if (((can_data[0] == nnb_copy) || (can_data[0] == 0xFF)) && (can_msg.ctrl == 0x01))
          {
            if (f_communication_open ==0)
            {
              f_communication_open = 1;
              isp_select_memory(MEM_DEFAULT);
              isp_select_page (PAGE_DEFAULT);
            }
            else
            {
              f_communication_open = 0;
            }
            f_frame_to_send = 1;
            can_tx[0] = BOOT_VERSION;
            can_tx[1] = f_communication_open;
            can_ctrl  = 2;
          }
          break;
        }

//------ Begin Old protocole
        #ifndef USE_RCS_CAN_PROTOCOL

        case CAN_ID_READ_FUNCTION:
        {
          if (f_communication_open)
          {
            f_frame_to_send 	= 1;
            can_ctrl          = 1;
            if(can_data[0]==0x00)
            {
              isp_select_memory(MEM_BOOT);
              restore_default_memspace = TRUE;
              can_tx[0] = isp_read (can_data[1]);
            }
            else if (can_data[0]==0x01)
            {
              isp_select_memory(MEM_XAF);
              restore_default_memspace = TRUE;
              can_tx[0] = isp_read (can_data[1]);
            }
          }
          break;
        }

      case CAN_ID_WRITE_FUNCTION:
        {
          if (f_communication_open)
          {
            if (!*can_data)
            {
               f_frame_to_send 	= 1;
               can_ctrl = 0x01;
               can_tx[0] = 0x00;
               goto label_isp_erase;   // ERASE
            }
            else if (*can_data==0x03) // Start application
            {
              address = ntohs(*(Uint16*)&can_data[2]);
              start_appli_type = can_data[1];
              can_start_appli_ready = TRUE;
            }
            else
            { // write configuration
              f_frame_to_send 	= 1;
              can_ctrl = 1;
              can_tx[0] = 0x00; // command ok
              isp_select_memory(MEM_XAF);
              restore_default_memspace = TRUE;
              isp_write(can_data[1],can_data[2]);
            }
          }
          break;
        }
        #endif /* USE_RCS_CAN_PROTOCOL */
//------ End Old Protocole

//------ Begin New protocole - JT.18.10.05
        #ifdef USE_RCS_CAN_PROTOCOL
        case CAN_ID_WRITE_FUNCTION:
        {
          if (f_communication_open)
          {
            if (*can_data==0x03) // Start application
            {
 	      address = can_data[2]<<8 | can_data[3];
              start_appli_type = can_data[1];
              can_start_appli_ready = TRUE;
            }
          }
          break;
        }
        #endif /* USE_RCS_CAN_PROTOCOL */
//------ End New Protocole - JT.18.10.05

        default:
        {
          break;
        }

      } // end of "switch ((can_msg.id.std - offset_id_copy))"

//      ENABLE_CHANNEL_RX; /* Reconfigure the channel.*/
    }
  } // end of "if (MOB_STATUS)"

/************** TRANSMISION MANAGEMENT ********************/
/********************************************************/

  if (f_frame_to_send)
  {
    CAN_SET_CHANNEL(CHANNEL_1);
    while(GetMObStatus(CHANNEL_1)) ; //wait channel free (end of last transmission)
    can_tx_id.std = can_msg.id.std;
    conf_tx      = can_ctrl;
    pt_candata_tx= can_tx;
    SendCanMsg();

    f_frame_to_send = 0;
  }
}

/*F****************************************************************************
* FUNCTION_NAME: send_error_security
*----------------------------------------------------------------------------
* FUNCTION_AUTHOR: BERTHY J.S.
* FUNCTION_DATE  :
*----------------------------------------------------------------------------
* FUNCTION_PURPOSE:
* FUNCTION_INPUTS : void
* FUNCTION_OUTPUTS: void
******************************************************************************/
void send_error_security (void)
{
  f_frame_to_send = 1;
  can_ctrl  = 0x01;
  can_msg.id.std = CAN_ID_ERROR_SECURITY + offset_id_copy;
  can_tx[0] = ERROR_SECURITY;

}

/*F**************************************************************************
* NAME: can_init_write_data
*----------------------------------------------------------------------------
* PARAMS:
* return:   none
*----------------------------------------------------------------------------
* PURPOSE:
*----------------------------------------------------------------------------
* EXAMPLE:
*----------------------------------------------------------------------------
* NOTE:
*----------------------------------------------------------------------------
* REQUIREMENTS:
*****************************************************************************/
void can_init_write_data(void)
{
 	address     = can_data[1]<<8 | can_data[2];
	end_address = can_data[3]<<8 | can_data[4];
  nb_byte_to_write = (Uint32)(end_address - address)+1 ;
  pt_buffer = 0;
}

/*F**************************************************************************
* NAME: can_init_display_data
*----------------------------------------------------------------------------
* PARAMS:
* return:   none
*----------------------------------------------------------------------------
* PURPOSE:
*----------------------------------------------------------------------------
* EXAMPLE:
*----------------------------------------------------------------------------
* NOTE:
*----------------------------------------------------------------------------
* REQUIREMENTS:
*****************************************************************************/
void can_init_display_data(void)
{
 	address     = can_data[1]<<8 | can_data[2];
	end_address = can_data[3]<<8 | can_data[4];
  nb_byte_to_read = (end_address - address)+1 ;
}

/*F**************************************************************************
* NAME: can_write_data
*----------------------------------------------------------------------------
* PARAMS:
* return:
*----------------------------------------------------------------------------
* PURPOSE:
*----------------------------------------------------------------------------
* EXAMPLE:
*----------------------------------------------------------------------------
* NOTE:
*----------------------------------------------------------------------------
* REQUIREMENTS:
*****************************************************************************/
Uchar can_write_data(void)
{
  Uchar status;
  Uchar cpt_var;

  for (cpt_var=0; (cpt_var<can_msg.ctrl)&&(nb_byte_to_write); cpt_var++,pt_buffer++,nb_byte_to_write--)
  {
    buffer[pt_buffer] = can_data[cpt_var];
  }
  if ((pt_buffer<=(PROTOCOL_DATA-8))&&(nb_byte_to_write))
  {
    status = COMMAND_NEW_DATA;
  }
  else if ((pt_buffer>(PROTOCOL_DATA-8))&&(nb_byte_to_write))
  {
    if(isp_write_block(buffer, address, pt_buffer)==FALSE)
    {
      status = COMMAND_SECURITY;
    }
    else
    {
      status = COMMAND_NEW_DATA;
      address += pt_buffer;
      pt_buffer = 0;
    }
  }
  else // if (nb_byte_to_write==0))
  {
    if(isp_write_block(buffer, address, pt_buffer)==FALSE)
    {
      status = COMMAND_SECURITY;
    }
    else
    {
      status = COMMAND_OK;
    }
  }
  return (status);
}

/*F**************************************************************************
* NAME: can_read_data
*----------------------------------------------------------------------------
* PARAMS:
* return:   none
*----------------------------------------------------------------------------
* PURPOSE:
*----------------------------------------------------------------------------
* EXAMPLE:
*----------------------------------------------------------------------------
* NOTE:
*----------------------------------------------------------------------------
* REQUIREMENTS:
*****************************************************************************/
void can_display_data(void)
{
  Uchar cpt;
  Uint16 state;

  do
  {
    if (nb_byte_to_read >= NB_DATA_MAX)
    {
      for (cpt=0; cpt<NB_DATA_MAX; cpt++, address++)
      {
        state = isp_read (address);
        if (HIGH(state))
        {
          send_error_security();
          return;
        }
        can_tx[cpt] = LOW(state);
      }
      nb_byte_to_read -= 8;

    }
    else
    {
      for (cpt=0; cpt<nb_byte_to_read; cpt++, address++)
      {
        state = isp_read (address);
        if (HIGH(state))
        {
          send_error_security();
          return;
        }
        can_tx[cpt] = LOW(state);
      }
      nb_byte_to_read = 0;

   }
    CAN_SET_CHANNEL(CHANNEL_1);
    while(GetMObStatus(CHANNEL_1)) ; // wait channel free (end of last transmission)
    can_tx_id.std = can_msg.id.std;
    conf_tx      = cpt;
    pt_candata_tx= can_tx;
    SendCanMsg();

  } while(nb_byte_to_read);

}
