/*C**************************************************************************
* $RCSfile: interface.c,v $
*----------------------------------------------------------------------------
* Copyright (c) 2003 Atmel.
*----------------------------------------------------------------------------
* RELEASE:      $Name: can11-bl-uart-can-0_0_8 $      
* REVISION:     $Revision: 1.2 $     
* FILE_CVSID:   $Id: interface.c,v 1.2 2003/07/04 16:45:49 njourdan Exp $       
*----------------------------------------------------------------------------
* PURPOSE: 
* Interface specification between:
* ISP Protocols and Memory Drivers
*****************************************************************************/

/*_____ I N C L U D E - F I L E S ____________________________________________*/
#define  _INTERFACE_C_
#include "config.h"
#include "interface.h"


/*_____ G L O B A L S ________________________________________________________*/
Uchar _MemType_ buffer[GLOBAL_BUFFER_SIZE];       // data received to program

// Variables used during the display command
Uint16          address;
Uint16          end_address;


// Do not add specific interface definition here.
// This file must stay generic.

