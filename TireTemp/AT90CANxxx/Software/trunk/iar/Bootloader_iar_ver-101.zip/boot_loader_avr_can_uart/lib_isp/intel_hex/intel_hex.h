/*C**************************************************************************
* $RCSfile: intel_hex.h,v $
*----------------------------------------------------------------------------
* Copyright (c) 2003 Atmel.
*----------------------------------------------------------------------------
* RELEASE:      $Name: c51rr2-bl-uart-0_0_1 $
* REVISION:     $Revision: 1.7.4.1 $
* FILE_CVSID:   $Id: intel_hex.h,v 1.7.4.1 2005/02/28 14:08:18 ybricard Exp $
*----------------------------------------------------------------------------
* PURPOSE:
*****************************************************************************/

#ifndef _INTEL_HEX_H_
#define _INTEL_HEX_H_

//!--------------------------------
//!INTEL HEX constant definition
//!--------------------------------
//!Intel hex processing states
#define PROTOC_WAIT_START       0
#define PROTOC_CHECKSUM         6

//!Intel hex record mark
#define HEX_RECORD_MARK         ':'

//! Intel Hex Frame field positions
#define INDEX_RECMARK           //! not used, automatically removed by the intel hex processing
#define INDEX_LEN               0
#define INDEX_OFFSET_HIGH       1
#define INDEX_OFFSET_LOW        2
#define INDEX_TYPE              3 //REC_TYPE
#define INDEX_DATA              4
#define INDEX_CHEKSUM           //! depends on INDEX_DATA and the data length of the frame


//!--------------------------------
//! BOOTLOADER
//!--------------------------------

//!Bootloader functions
#define BL_WRITE_ID                 0x00
#define BL_START_APP_ID             0x01
#define BL_SELECT_PAGE_ID           0x02

#define BL_APPLI_MODE_ID           0x03
  #define BL_APPLI_MODE_SUB_ID1    0x03

#define BL_SELECT_MEMORY_ID         0x04
  #define BL_SELECT_MEMORY_SUB_ID1  0x02

#define BL_READ_ID                  0x04
  #define BL_READ_SUB_ID1           0x05
  #define BL_READ_SUB_ID2           0x00

#define BL_BLANK_CHECK_ID           0x04
  #define BL_BLANK_CHECK_SUB_ID1    0x05
  #define BL_BLANK_CHECK_SUB_ID2    0x01

#define BL_ERASE_ID                 0x04
  #define BL_ERASE_SUB_ID1          0x05
  #define BL_ERASE_SUB_ID2          0x02


/*
#define ID_FUNCTION_WR_FLASH    0x00
#define ID_FUNCTION_EOF         0x01 // End Of File Intel HEX Object
#define ID_FUNCTION_EXT_SEG     0x02 // Extended Segment Address Record
#define ID_FUNCTION_WRITE       0x03
#define ID_FUNCTION_EXT_ADDR    0x04 // Extended Linear Address Record
#define ID_FUNCTION_DISPLAY     0x04
#define ID_FUNCTION_READ        0x05
#define ID_FUNCTION_WR_EEPROM   0x07
#define ID_FUNCTION_WR_CUSTOM   0x08

#define ID_PRG_SSB_LEVEL_1      0x00
#define ID_PRG_SSB_LEVEL_2      0x01

#define ID_SUB_FUNCTION_ERASE_BLOCK     0x01
#define ID_SUB_FUNCTION_START_APPLI     0x03
#define ID_SUB_FUNCTION_ERASE_SBV_BSB   0x04
#define ID_SUB_FUNCTION_PRG_SSB         0x05
#define ID_SUB_FUNCTION_PRG_BSB_SBV     0x06
#define ID_SUB_FUNCTION_FULL_ERASE      0x07
#define ID_SUB_FUNCTION_PRG_FUSE        0x0A

#define ID_SUB_FUNCTION_DISP_DATA       0x00
#define ID_SUB_FUNCTION_DISP_BLANK_CHECK 0x01
#define ID_SUB_FUNCTION_DISP_EEPROM     0x02
#define ID_SUB_FUNCTION_DISP_CUSTOM     0x03

#define ID_SUB_FUNCTION_RD_ID           0x00
#define ID_SUB_FUNCTION_RD_SSB          0x07
#define ID_SUB_FUNCTION_RD_HSB          0x0B
#define ID_SUB_FUNCTION_RD_BOOT_ID      0x0E
#define ID_SUB_FUNCTION_RD_BOOT_VERSION 0x0F
*/


extern void intel_hex_init (void);
extern void intel_hex (void);


#endif

