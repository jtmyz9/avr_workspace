/*H**************************************************************************
* $RCSfile: interface.h,v $         
*----------------------------------------------------------------------------
* Copyright (c) 2003 Atmel.
*----------------------------------------------------------------------------
* RELEASE:      $Name: can11-bl-uart-can-0_0_8 $      
* REVISION:     $Revision: 1.9 $     
* FILE_CVSID:   $Id: interface.h,v 1.9 2003/09/26 07:51:11 jberthy Exp $       
*----------------------------------------------------------------------------
* PURPOSE: 
* Interface specification between:
* ISP Protocols and Memory Drivers
*****************************************************************************/
#ifndef _INTERFACE_H_
#define _INTERFACE_H_

/*_____ I N C L U D E S ____________________________________________________*/

/*_____ M A C R O S ________________________________________________________*/

/*_____ D E F I N I T I O N ________________________________________________*/
/*V**************************************************************************
* NAME: buffer 
*----------------------------------------------------------------------------
* PURPOSE: 
* Stores the received frame, global variable used by boot protocol stack
*****************************************************************************/
extern Uchar _MemType_  buffer[];       // data received to program
extern Uint16           address;
extern Uint16           end_address;


/*_____ D E C L A R A T I O N S ____________________________________________*/
/*F**************************************************************************
* NAME: isp_select_memory
*----------------------------------------------------------------------------
* PARAMS:   
* id: identifier of the memory area (Byte).
*       id = 00     : USER, CODE, FLASH, CRAM
*       id = 01     : EEPROM
*       id = 02     : CUSTOM
*       id = 03     : BOOT
*       id = 04     : XAF
*       id = 05     : HW (Hardware Byte)
*       id = 06     : SIGNATURE (Hard Signatures of the product) 
*       id = 07     : LPC_BOOT (only for the LPC protocol)
*       id = 128    : MULTICAST
* return: none
*----------------------------------------------------------------------------
* PURPOSE:
* select a memory area.
*----------------------------------------------------------------------------
* EXAMPLE:
* isp_select_memory(0x04) selects the XAF area.
*----------------------------------------------------------------------------
* NOTE: 
*----------------------------------------------------------------------------
* REQUIREMENTS: 
*****************************************************************************/
extern void   isp_select_memory       (Byte id);


/*F**************************************************************************
* NAME: isp_select_page
*----------------------------------------------------------------------------
* PARAMS:   
* page: identifier of the page (Byte).
* return: none
*----------------------------------------------------------------------------
* PURPOSE:
* select a 64KB page of a memory area.
*----------------------------------------------------------------------------
* EXAMPLE:
* isp_select_page(0x02) selects the third page of a memory
* (address range: 128KB -> 192KB).
*----------------------------------------------------------------------------
* NOTE: 
* This function was added to address a memory space that contains more bytes 
* than 64KB.
* A page contains 64 KB.
* The default page is 0 (0 -> 64 KB).
*----------------------------------------------------------------------------
* REQUIREMENTS: 
*****************************************************************************/
extern void   isp_select_page         (Byte page);


/*F**************************************************************************
* NAME: isp_erase
*----------------------------------------------------------------------------
* PARAMS:   
* block: identifier of the block (Byte).
*       block = 00h erase the block 0KB  -> 8KB
*       block = 20h erase the block 8KB  -> 16KB
*       block = 40h erase the block 16KB -> 32 KB
*       block = FFh full chip erase
* return: TRUE if the erasing is good and FALSE if there is an error (bit).
*----------------------------------------------------------------------------
* PURPOSE:
* erase a block into the selected memory or erase all the selected memory.
*----------------------------------------------------------------------------
* EXAMPLE:
* isp_erase(0xFF) erases all the selected memory.
*----------------------------------------------------------------------------
* NOTE: 
* 0xFF is the id to erase all the selected memory.
*----------------------------------------------------------------------------
* REQUIREMENTS: 
*****************************************************************************/
extern bit    isp_erase               (Byte block);


/*F**************************************************************************
* NAME: isp_read
*----------------------------------------------------------------------------
* PARAMS:   
* addr: address of the byte to read (2 Bytes)
* return: FFFFh if there is a problem of reading or 0x00XX if the reading is
*         good. XX is the read byte. 
*----------------------------------------------------------------------------
* PURPOSE:
* read the byte at the address addr into the selected memory.
*----------------------------------------------------------------------------
* EXAMPLE:
* isp_read(0x0052) reads the byte at the address 0xMMPP0052 (MM=Memory PP=Page).
*----------------------------------------------------------------------------
* NOTE: 
* Even if there is only one byte to read, the function isp_read_block may
* be called instead of isp_read.
*----------------------------------------------------------------------------
* REQUIREMENTS: 
*****************************************************************************/
extern Uint16 isp_read                (Uint16 addr);


/*F**************************************************************************
* NAME: isp_read_block
*----------------------------------------------------------------------------
* PARAMS:   
* src: address of the first element of the table that contains the values
*      to read.
* dest: destination address of the first value of the buffer (2 Bytes).
* n: number of bytes to read.
* return: TRUE if the reading is good and FALSE if there is an error (bit).
*----------------------------------------------------------------------------
* PURPOSE:
* Read a block of data into the selected memory
*----------------------------------------------------------------------------
* EXAMPLE:
* isp_read_block (0x0083, idata_buffer, 0x0A) read the 10 bytes at the
* addresses 0x0083 -> 0x008C and store it into the buffer.
*----------------------------------------------------------------------------
* NOTE: 
* This function allows the user to perform a bulk read, up to 255 bytes.
* This function should be mapped on low-level bulk read calls.
* Even if there is only one byte to read, the function isp_read_block may
* be called instead of isp_read.
*----------------------------------------------------------------------------
* REQUIREMENTS: 
*****************************************************************************/
extern bit    isp_read_block           (Uint16 src, Byte _MemType_* dest, Byte n);


/*F**************************************************************************
* NAME: isp_write
*----------------------------------------------------------------------------
* PARAMS:   
* addr: address in which the byte must be written (2 Bytes).
* value: value to write (1 Byte).
* return: TRUE if the writing is good and FALSE if there is an error (bit).
*----------------------------------------------------------------------------
* PURPOSE:
* Write a byte at the address addr into the selected memory.
*----------------------------------------------------------------------------
* EXAMPLE:
* isp_write(0x0001, 0xAA) writes AA at the address 0001.
*----------------------------------------------------------------------------
* NOTE: 
* Even if there is only one byte to write, the function isp_write_block may
* be called instead of isp_write.
*----------------------------------------------------------------------------
* REQUIREMENTS: 
*****************************************************************************/
extern bit    isp_write               (Uint16 addr, Uchar value);


/*F**************************************************************************
* NAME: isp_write_block
*----------------------------------------------------------------------------
* PARAMS:   
* src: address of the first element of the table that contains the values
*      to write.
* dest: destination address of the first value of the table (2 Bytes).
* n: number of values to write.
* return: TRUE if the writing is good and FALSE if there is an error (bit).
*----------------------------------------------------------------------------
* PURPOSE:
* write a block of data into the selected memory
*----------------------------------------------------------------------------
* EXAMPLE:
* isp_write_block (idata_table, 0x0083, 0x0A) writes the 10 bytes contained into
* the table data_table at the addresses 0x0083 -> 0x008C.
*----------------------------------------------------------------------------
* NOTE: 
* This function allows the user to write a block of up to 255 bytes.
* This function should be mapped on low-level page write calls.
* Even if there is only one byte to write, the function isp_write_block may
* be called instead of isp_write.
*----------------------------------------------------------------------------
* REQUIREMENTS: 
*****************************************************************************/
extern bit    isp_write_block           (Byte _MemType_* src, Uint16 dest, Byte n);


/*F**************************************************************************
* NAME: isp_reset
*----------------------------------------------------------------------------
* PARAMS:   
* config: selects the reset option.
*       config = 00h : hardware reset
*       config = 01h : long jump at address specified in global 
*                      parameters
* return: TRUE if the reset is good and FALSE if there is an error (Bit).
*----------------------------------------------------------------------------
* PURPOSE:
* reset or long jump.
*----------------------------------------------------------------------------
* EXAMPLE:
* isp_erase(0x00)   makes an hardware reset.
*----------------------------------------------------------------------------
* NOTE: 
* The config byte allows the user to make a Long Jump.
*----------------------------------------------------------------------------
* REQUIREMENTS: 
*****************************************************************************/
extern bit    isp_reset               (Byte config);


/*F**************************************************************************
* NAME: isp_blank_check
*----------------------------------------------------------------------------
* PARAMS:   
* start: start address (2 bytes).
* end:   end address (2 bytes).
* return: 0x00000000 if the selected memory is blank or FFFFXXXXh if the 
* selected memory isn't blank. XXXX contains the address of the first byte
* that isn't blank. 
*----------------------------------------------------------------------------
* PURPOSE:
* Check if the selected memory is blank between the start addr and 
* the end addr.
*----------------------------------------------------------------------------
* EXAMPLE:
* isp_blank_check(0x0000, 0x7FFF) checks if the 32 KB of the selected memory
* are blank. 
*----------------------------------------------------------------------------
* NOTE: 
*----------------------------------------------------------------------------
* REQUIREMENTS: 
*****************************************************************************/
extern Uint32 isp_blank_check         (Uint16 start,Uint16 end);


#endif  /* INTERFACE_H */


