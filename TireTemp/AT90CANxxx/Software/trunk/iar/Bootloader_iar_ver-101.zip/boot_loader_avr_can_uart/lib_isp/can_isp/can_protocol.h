/*H**************************************************************************
* $RCSfile: can_protocol.h,v $         
*----------------------------------------------------------------------------
* Copyright (c) 2003 Atmel.
*----------------------------------------------------------------------------
* RELEASE:      $Name: can11-bl-uart-can-0_0_8 $      
* REVISION:     $Revision: 1.4 $     
* FILE_CVSID:   $Id: can_protocol.h,v 1.4 2003/10/24 07:52:48 jberthy Exp $       
*----------------------------------------------------------------------------
* PURPOSE: 
* This file contains the CAN protocol task definition
*****************************************************************************/

#ifndef _CAN_ISP_PROTOCOL_H_
#define _CAN_ISP_PROTOCOL_H_

/*_____ I N C L U D E S ____________________________________________________*/


/*_____ D E S C R I P T O R    T Y P E S ____________________________________*/


/*_____ S T A N D A R D    F E A T U R E S __________________________________*/


#define MAX_OFFSET_ID 0x7F0
#define ERROR_SECURITY  0x00


/********** COMMAND FOR PROTOCOL  */
#define CAN_ID_SELECT_NODE          0x00
#define CAN_ID_PROG_START           0x01
#define CAN_ID_PROG_DATA            0x02
#define CAN_ID_DISPLAY_DATA         0x03
#define CAN_ID_WRITE_FUNCTION       0x04
#define CAN_ID_READ_FUNCTION        0x05
#define CAN_ID_CHANGE_BASE_ADDR     0x06
#define CAN_ID_ERROR_SECURITY       0x06

#define COMMAND_OK        0x00
#define COMMAND_FAIL      0x01
#define COMMAND_NEW_DATA  0x02
#define COMMAND_SECURITY  0x03

/*_____ D E C L A R A T I O N ______________________________________________*/

extern void can_init_from_appli(void);
extern void can_init_from_reset(void);
extern void can_protocol_task_init(void);
extern void can_protocol_task(void);
#endif  /* _CAN_PROTOCOL_H_ */

