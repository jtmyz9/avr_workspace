/*C**************************************************************************
* NAME:         main.c
*----------------------------------------------------------------------------
* Copyright (c) 2002 Atmel.
*----------------------------------------------------------------------------
* RELEASE:      c5122-bl-1_9_91
* REVISION:     1.13
*----------------------------------------------------------------------------
* PURPOSE:
*
*****************************************************************************/

/*_____ I N C L U D E S ____________________________________________________*/
#include "config.h"
#include "lib_mcu/flash/flash_lib.h"
#include "lib_mcu/eeprom/eeprom.h"
#include "lib_mcu/uart/uart_lib.h"
/*_____ M A C R O S ________________________________________________________*/

/*_____ D E F I N I T I O N S ______________________________________________*/

/*_____ D E C L A R A T I O N S ____________________________________________*/

Byte code mem_boot[]={ BOOT_VERSION, BOOT_ID1, BOOT_ID2 };

#pragma location ="BOOT_CONF"
Byte code boot_conf []={  // This table is used in config.h, don't change the byte position.
BSB_DEFAULT , 0x01, 0x02, 0x03, 0x04, SSB_DEFAULT , EB_DEFAULT ,
0x07, 0x08, 0x09, 0x0A, 0x0B, 0x0C,0x0D,0x0E,0x0F,
0x10, 0x11, 0x12, 0x13, 0x14, 0x15, 0x16, 0x17, 0x18, 0x19, 0x1A, 0x1B,
BTC1_DEFAULT, BTC2_DEFAULT, BTC3_DEFAULT, NNB_DEFAULT, CRIS_DEFAULT };


Byte code manuf_conf[]={MANUF_ID, FAMILY_CODE, PRODUCT_NAME, PRODUCT_REV};


Byte isp_memory_space;
Byte isp_page;

//!****************************************************************************
//! NAME: isp_select_memory (Byte page)
//!----------------------------------------------------------------------------
//! PARAMS:
//! return: none
//!----------------------------------------------------------------------------
//! PURPOSE:
//! Select the memory on which operation will be performed
//!----------------------------------------------------------------------------
//! EXAMPLE:
//!----------------------------------------------------------------------------
//! NOTE:
//!----------------------------------------------------------------------------
//! REQUIREMENTS:
//!****************************************************************************/
void isp_select_memory (Byte id)
{
  isp_memory_space = id;
}


//!****************************************************************************
//! NAME: isp_select_page (Byte page)
//!----------------------------------------------------------------------------
//! PARAMS:
//! return: none
//!----------------------------------------------------------------------------
//! PURPOSE:
//! Define the current page number for flash area
//! on the intel hex format, one page is 64K bytes large
//!----------------------------------------------------------------------------
//! EXAMPLE:
//!----------------------------------------------------------------------------
//! NOTE:
//!----------------------------------------------------------------------------
//! REQUIREMENTS:
//!****************************************************************************/
void isp_select_page (Byte page)
{
  if (isp_memory_space == MEM_FLASH)
    isp_page = page;
}


//!****************************************************************************
//! NAME: isp_erase (Byte block)
//!----------------------------------------------------------------------------
//! PARAMS:
//! return: none
//!----------------------------------------------------------------------------
//! PURPOSE:
//!----------------------------------------------------------------------------
//! EXAMPLE:
//!----------------------------------------------------------------------------
//! NOTE:
//!----------------------------------------------------------------------------
//! REQUIREMENTS:  available for
//!         FM0 and EE0 memories,
//!****************************************************************************/
bit isp_erase (Byte block)
{
  bit state = TRUE;

  if (isp_memory_space == MEM_FLASH)
  {
    flash_erase();
    flash_wr_byte((Uint32)&BSB,BSB_DEFAULT);
    flash_wr_byte((Uint32)&SSB,SSB_DEFAULT);
  }
  else if ((isp_memory_space == MEM_EEPROM)&&(SSB==SSB_DEFAULT)) eeprom_erase();
  else if (SSB!=SSB_DEFAULT) state = FALSE;
  return state;
}


//!****************************************************************************
//! NAME: isp_read (Uint16 addr)
//!----------------------------------------------------------------------------
//! PARAMS:
//! return: none
//!----------------------------------------------------------------------------
//! PURPOSE:
//!----------------------------------------------------------------------------
//! EXAMPLE:
//!----------------------------------------------------------------------------
//! NOTE:
//!----------------------------------------------------------------------------
//! REQUIREMENTS:  available for
//!         FM0 and EE0 memories,
//!         Security block (HSB)
//!         User Configuration block (FCB)
//!****************************************************************************/
Uint16 isp_read (Uint16 addr)
{
  switch (isp_memory_space)
  {
    case MEM_SIGNATURE:
    //! manufacturer information
    //! independant from security level
      if (addr == 0x30)   return MANUF_ID;
      if (addr == 0x31)   return FAMILY_CODE;
      if (addr == 0x60)   return PRODUCT_NAME;
      if (addr == 0x61)   return PRODUCT_REV;
      break;

    case MEM_BOOT:
    //! bootloader information
    //! independant from security level
      if (addr == 0x00)  return BOOT_VERSION;
      if (addr == 0x01)  return BOOT_ID1;
      if (addr == 0x02)  return BOOT_ID2;
      break;

    case MEM_XAF:
    //! bootloader configuration
    //! independant from security level
      if (addr<ADDR_CONF_MAX)  return (boot_conf[addr]);
      break;

    case MEM_FLASH:
    //! FLASH access
    //! dependant from security level
      if (SSB==SSB_RD_PROTECTION)
      {
        return SECUR16;
      }
      else
      {
        return(flash_rd_byte((Uchar __FLASHTYPE*)((Uint32)isp_page<<16)+addr));
      }
      break;

    case MEM_EEPROM:
    //! EEPROM access
    //! dependant from security level
      if (SSB==SSB_RD_PROTECTION) return SECUR16;
      else
      {
        return (eeprom_rd_byte(addr));
      }
      break;

   default:
   break;
   }

  return 0;
}

//!****************************************************************************
//! NAME: isp_write (Uint16 addr, Uchar value)
//!----------------------------------------------------------------------------
//! PARAMS:
//! return: none
//!----------------------------------------------------------------------------
//! PURPOSE:
//!----------------------------------------------------------------------------
//! EXAMPLE:
//!----------------------------------------------------------------------------
//! NOTE:
//!----------------------------------------------------------------------------
//! REQUIREMENTS:  available for
//!         FM0 and EE0 memories,
//!         Security block (HSB)
//!         User Configuration block (FCB)
//!****************************************************************************
bit isp_write (Uint16 addr, Uchar value)
{

  if ((isp_memory_space == MEM_XAF)&&(addr==0x05)) // SSB accessed
  {
    if (value < SSB) flash_wr_byte((Uint32)&boot_conf[addr],value);
    else return FALSE;
  }
  else if (SSB != SSB_DEFAULT) return FALSE;
  if (isp_memory_space == MEM_FLASH) flash_wr_byte((((Uint32)isp_page<<16)+(Uint32)addr),value);
  if (isp_memory_space == MEM_EEPROM) eeprom_wr_byte(addr,value);
  if ((isp_memory_space == MEM_XAF)&&(addr<ADDR_CONF_MAX))
  {
    flash_wr_byte((Uint32)&boot_conf[addr],value);
  }
  return TRUE;
}

//!****************************************************************************
//! NAME: isp_write_block (Byte* src, Uint16 dest, Byte n)
//!----------------------------------------------------------------------------
//! PARAMS:
//! return: none
//!----------------------------------------------------------------------------
//! PURPOSE:
//!----------------------------------------------------------------------------
//! EXAMPLE:
//!----------------------------------------------------------------------------
//! NOTE:
//!----------------------------------------------------------------------------
//! REQUIREMENTS:
//! only available for FM0 and EE0 memory area
//!****************************************************************************/
bit isp_write_block (Byte* src, Uint16 dest, Byte n)
{
  if ((isp_memory_space == MEM_XAF)&&(dest==0x05)) // SSB accessed
  {
    if (isp_write(dest,*src)==TRUE) return TRUE;
    else return FALSE;
  }
  else if (SSB != SSB_DEFAULT) return FALSE;
  if (isp_memory_space == MEM_FLASH) flash_wr_block (src,(((Uint32)isp_page<<16)+(Uint32)dest),n);
  if (isp_memory_space == MEM_EEPROM) eeprom_wr_block (src,dest, n);
  if ((isp_memory_space == MEM_XAF)&&(n==1)) isp_write(dest,*src);
  return TRUE;
}

//!****************************************************************************
//! NAME: isp_reset (Byte config)
//!----------------------------------------------------------------------------
//! PARAMS:
//! return: none
//!----------------------------------------------------------------------------
//! PURPOSE:
//! wait for a hardware reset of the processor
//!----------------------------------------------------------------------------
//! EXAMPLE:
//!----------------------------------------------------------------------------
//! NOTE: This function enable the processor to restart from the entry point
//! configured in the reset configuration register
//!----------------------------------------------------------------------------
//! REQUIREMENTS:
//!****************************************************************************/
bit isp_reset (Byte config)
{ // extern address data variable is set to LJMP addr to use
  if (!config) /* hardware reset */
  {
    WDTCR |= 1<<WDE;
    while(1);
  }
  else          /* Long_call to 0x0000*/
  {
    asm ("ldi R31, 0x00");
    asm ("ldi R30, 0x00");
    asm ("ijmp");
  }
  return TRUE;
}

//!****************************************************************************
//! NAME: isp_blank_check (Uint16 start,Uint16 end)
//!----------------------------------------------------------------------------
//! PARAMS:
//! return: none
//!----------------------------------------------------------------------------
//! PURPOSE:
//! Verify that the memory area selected has been erased successfully
//!----------------------------------------------------------------------------
//! EXAMPLE:
//!----------------------------------------------------------------------------
//! NOTE:
//! Address mask change from 0xFFFF0000L to 0xFFFE0000L to support up to 128kbyte
//!----------------------------------------------------------------------------
//! REQUIREMENTS:
//!****************************************************************************/
Uint32 isp_blank_check (Uint16 start,Uint16 end)
{
  do
  {
      if (((isp_memory_space== MEM_FLASH) && (flash_rd_byte((Uchar __FLASHTYPE*)((Uint32)isp_page<<16)+start)!=FLASH_BLANK_VALUE)) ||
          ((isp_memory_space== MEM_EEPROM) && (eeprom_rd_byte(start)!=EEPROM_BLANK_VALUE)))
      {
          return (Uint32)start|0xFFFF0000L;
      }
    } while (start++<end);
  return 0;
}

