//*****************************************************************************
//  $RCSfile: config.h,v $
//-----------------------------------------------------------------------------
//  Copyright (c) 2003 Atmel.
//-----------------------------------------------------------------------------
//  RELEASE:      $Name: avr-can11-lib-mcu-0_0_3 $
//  REVISION:     $Revision: 1.2 $
//  FILE_CVSID:   $Id: config.h,v 1.2 2004/03/29 11:09:59 jberthy Exp $
//-----------------------------------------------------------------------------
//  PURPOSE:
//  Configuration file. Selection of the device.
//*****************************************************************************
#ifndef _CONFIG_H_
#define _CONFIG_H_

//---------------- PROCESSOR DEFINITION ----------------
// NB! These 'defines' must be placed before the include files

// Global
#define AVR
#define AT90CAN128  1
#define AT90CAN64   2
#define AT90CAN32   3

// Hardware condition (for boot or application start)
  // INT on DVK90CAN1 board = INT0 or PD.0 - active low with pullup
    #define PIN_HWCB      PIND_Bit0
    #define PORT_HWCB     PORTD_Bit0
    #define LEVEL_HWCB    0           // active at "0" or "1"
    #define PULLUP_HWCB   1           // pullup "ON"="1", "OFF"="0"
/*  // Center Key on DVK90CAN1 board = PE.2 active low with pullup
    #define PIN_HWCB      PINE_Bit2
    #define PORT_HWCB     PORTE_Bit2
    #define LEVEL_HWCB    0           // active at "0" or "1"
    #define PULLUP_HWCB   1           // pullup "ON"="1", "OFF"="0" */

// Apllication
#define USE_DEVICE   AT90CAN32
#define USE_UART1
#define FOSC         8000

// Switches for Specific definitions
#ifndef USE_DEVICE
#       error You must define USE_DEVICE AT90CAN128 or AT90CAN64 or AT90CAN32 first in "config.h" file
#   elif USE_DEVICE == AT90CAN128
#       define MANUF_ID         0x1E        // ATMEL
#       define FAMILY_CODE      0x97        // 128 Kbytes of Flash
#       define PRODUCT_NAME     0x81        // AT90CAN family
#       define PRODUCT_REV      0x00        // rev 0
#       define FLASH_SIZE       0x1FFFF     // in bytes
#       define FLASH_PAGE_SIZE  0x100       // in bytes
#       define BOOT_SIZE        0x2000      // in bytes
#       define EEPROM_SIZE      0x1000      // in bytes
#   elif USE_DEVICE == AT90CAN64
#       define MANUF_ID         0x1E        // ATMEL
#       define FAMILY_CODE      0x96        // 64 Kbytes of Flash
#       define PRODUCT_NAME     0x81        // AT90CAN family
#       define PRODUCT_REV      0x00        // rev 0
#       define FLASH_SIZE       0x0FFFF     // in bytes
#       define FLASH_PAGE_SIZE  0x100       // in bytes
#       define BOOT_SIZE        0x2000      // in bytes
#       define EEPROM_SIZE      0x0800      // in bytes
#   elif USE_DEVICE == AT90CAN32
#       define MANUF_ID         0x1E        // ATMEL
#       define FAMILY_CODE      0x95        // 32 Kbytes of Flash
#       define PRODUCT_NAME     0x81        // AT90CAN family
#       define PRODUCT_REV      0x00        // rev 0
#       define FLASH_SIZE       0x07FFF     // in bytes
#       define FLASH_PAGE_SIZE  0x100       // in bytes
#       define BOOT_SIZE        0x2000      // in bytes
#       define EEPROM_SIZE      0x0400      // in bytes
#   else
#       error USE_DEVICE definition is not (well) referenced in "config.h" file
#endif

#ifndef USE_UART1
#       ifndef USE_UART2
#               error You must define either USE_UART1 or USE_UART2 in "config.h" file
#       endif
#endif

// Polling pins definition
#ifdef USE_UART1
#   define PIN_UART_RX     PINE_Bit0        // for UART0
#   define PORT_UART_TX    PORTE_Bit1       // for UART0
#endif
#ifdef USE_UART2
#   define PIN_UART_RX     PIND_Bit2        // for UART1
#   define PORT_UART_TX    PORTD_Bit3       // for UART1
#endif

#define PIN_CAN_RX      PIND_Bit6
#define PORT_CAN_TX     PORTD_Bit5


//---------------- INCLUDE FILES ----------------
#include "lib_mcu/compiler.h"
#include "lib_mcu/mcu.h"
#include "lib_mcu/mcu_drv.h"

//---------------- DEBUG DEFINITION ----------------
// All defines must be remove berfore a release
//#define DEBUG_BYPASSAUTOBAUD    // CAN 100kbs & CKIO 8MHz
//#define DEBUG_ISP_RD_COMMAND
//#define DEBUG_FLASHWR           // If program is mapped in application area

//------------- STANDARD FLASH MEMORY DEFINITION ---------------
#define Enable_flash()
#define Disable_flash()

//------------- STANDARD EEPROM MEMORY DEFINITION -------------
#define Enable_eeprom()
#define Disable_eeprom()

//------------- CAN DEFINITION -------------


//-------------- UART LIB CONFIGURATION ---------------
#define UART_AUTOBAUD_EXTERNAL_DETECTION
#define UART_MINIMUM
#define BDR_GENERATOR BRG_TIMER1
#define BAUDRATE    AUTOBAUD
//#define BAUDRATE    19200
#define test_hit()  uart_test_hit()
#define _getkey()   uart_getchar()
#define putchar     uart_putchar

//--------------- SCHEDULER CONFIGURATION --------------
#define SCHEDULER_TYPE          SCHEDULER_FREE  // SCHEDULER_(TIMED|TASK|FREE|CUSTOM)
#define Scheduler_task_1_init   boot_process
#define Scheduler_task_1        protocol_task
#define scheduler               main



#define ENTRY_POINT_USER_PRG    0


//-------------- BOOTLOADER CONFIGURATION -------------
// Uart protocol
#define PROTOCOL_DATA                   64
#define GLOBAL_BUFFER_SIZE              PROTOCOL_DATA+4
#define NB_BYTE_MAX_FOR_DISPLAY_COMMAND 64
#define HEX_SIZE_DISP_PAGE              16

//#undef USE_RCS_HEX_PROTOCOL
#define USE_RCS_HEX_PROTOCOL
#define USE_RCS_CAN_PROTOCOL

//----------- Bootloader identification definition ----
// Boot Mem Def
#define BOOT_VERSION    0x01 //0x10 // @00  // Ver 01: JT-18.10.05
#define BOOT_ID1        0xD1 // 2   // @01
#define BOOT_ID2        0xD2 // 0   // @02

#define SECUR32 0xF0F0F0F0
#define SECUR16 0xF0F0
#define SECUR8  0xF0

#define NO_SECURITY     0xFF
#define RD_WR_SECURITY  0xFC
#define BSB_DEFAULT     0xFF
#define SSB_DEFAULT     0xFF
#define EB_DEFAULT      0xFF
#define NNB_DEFAULT     0xFF
#define CRIS_DEFAULT    0xFF
#define BTC1_DEFAULT    0xFF
#define BTC2_DEFAULT    0xFF
#define BTC3_DEFAULT    0xFF

#define SSB_RD_PROTECTION 0xFC
#define SSB_WR_PROTECTION 0xFE

#define BSB boot_conf[0]
#define SSB boot_conf[5]
#define EB  boot_conf[6]
#define BTC1 boot_conf[0x1C]
#define BTC2 boot_conf[0x1D]
#define BTC3 boot_conf[0x1E]
#define NNB  boot_conf[0x1F]
#define CRIS boot_conf[0x20]

//-------- Memory Definition -----------------
#define MEM_USER                0
#define MEM_CODE                0
#define MEM_FLASH               0
#define MEM_EEPROM              1
#define MEM_CUSTOM              2
#define MEM_BOOT                3   // Boot information
#define MEM_XAF                 4   // Boot configuration
#define MEM_HW                  5
#define MEM_SIGNATURE           6
#define MEM_MULTICAST           128
#define MEM_DEFAULT MEM_FLASH

#define PAGE_DEFAULT  0x00

#define ADDR_CONF_MAX 0x21

#ifndef __IAR_SYSTEMS_ASM__
 extern Uchar code boot_conf[];
#endif

#ifdef _INTEL_HEX_C_
#include "lib_mcu/uart/uart_lib.h"
#endif

#endif  // CONFIG_H
