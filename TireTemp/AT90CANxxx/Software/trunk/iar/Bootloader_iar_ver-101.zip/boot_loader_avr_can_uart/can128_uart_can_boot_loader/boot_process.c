/*C**************************************************************************
* $RCSfile: boot_process.c,v $
*----------------------------------------------------------------------------
* Copyright (c) 2003 Atmel.
*----------------------------------------------------------------------------
* RELEASE:      $Name: can11-bl-uart-can-0_0_8 $
* REVISION:     $Revision: 1.5 $
* FILE_CVSID:   $Id: boot_process.c,v 1.5 2003/09/04 15:55:46 jberthy Exp $
*----------------------------------------------------------------------------
* PURPOSE:
* This file contains the boot process description.
* This function must be the first one called after reset
*****************************************************************************/
/*_____ I N C L U D E - F I L E S ____________________________________________*/

#include "config.h"
#include "lib_isp/can_isp/can_protocol.h"
#include "lib_isp/intel_hex/intel_hex.h"
#include "lib_mcu/uart/uart_lib.h"

/*_____ G L O B A L S ________________________________________________________*/
Uchar protocol_select;

/*_____ P R I V A T E - F U N C T I O N S - D E C L A R A T I O N ____________*/
#define _PROTOCOL_UART  0
#define _PROTOCOL_CAN   1


/*_____ L O C A L S __________________________________________________________*/


/*F**************************************************************************
* NAME: boot_process
*----------------------------------------------------------------------------
* PARAMS:
* return:   none
*----------------------------------------------------------------------------
* PURPOSE:
* This function allows to execute the bootloader or the application.
*----------------------------------------------------------------------------
* EXAMPLE:
*----------------------------------------------------------------------------
* NOTE: This function must be the first function called after reset
*----------------------------------------------------------------------------
* REQUIREMENTS:
*****************************************************************************/
void boot_process (void)
{
  bit hwcb = FALSE;
  register Uchar status = TRUE;

// Configure Hardware Condition Input
  // Note: Port in "INPUT MODE" after RESET
  if (PULLUP_HWCB==1) PORT_HWCB=1;
  hwcb = PIN_HWCB;
  if (LEVEL_HWCB==0) hwcb = (~hwcb) & 0x01;

// Start APPLICATION else Start BOOTLOADER
  if (((BSB!=BSB_DEFAULT)&&(hwcb==0))||((BSB==BSB_DEFAULT)&&(hwcb ==1))) asm("JMP 0");

// Wait a activity on the CAN or on the UART
  PORT_UART_TX=1;   // Pull-up on UART_Tx
  PORT_CAN_TX=1;    // Pull-up on CAN_Tx
  do{
    if (PIN_UART_RX ==0)
    {
      uart_init();
      putchar('U');
      status = FALSE;
      protocol_select = _PROTOCOL_UART;
    }else if(PIN_CAN_RX == 0)
    {
      can_init_from_reset();
      status = FALSE;
      protocol_select = _PROTOCOL_CAN;
    }
  }while(status);

  if (protocol_select == _PROTOCOL_UART)
  {
    intel_hex_init();
  }
  else
  {
    can_protocol_task_init();
  }

}


/*F**************************************************************************
* NAME: protocol_task
*----------------------------------------------------------------------------
* PARAMS:
* return:   none
*----------------------------------------------------------------------------
* PURPOSE:
* This function manage the protocol selected
*----------------------------------------------------------------------------
* EXAMPLE:
*----------------------------------------------------------------------------
* NOTE:
*----------------------------------------------------------------------------
* REQUIREMENTS:
*****************************************************************************/
void protocol_task (void)
{
  if (protocol_select == _PROTOCOL_UART)
  {
    intel_hex();
  }
  else
  {
    can_protocol_task();
  }
}




