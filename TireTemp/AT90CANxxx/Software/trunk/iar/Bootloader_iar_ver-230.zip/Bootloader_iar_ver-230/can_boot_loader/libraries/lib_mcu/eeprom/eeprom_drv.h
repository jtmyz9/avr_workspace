//**************************************************************************
//! @file $RCSfile: can_boot_drv.h,v $
//!
//! Copyright (c) 2006 Atmel.
//!
//! Use of this program is subject to Atmel's End User License Agreement.
//! Please read file license.txt for copyright notice.
//!
//! @brief This file contains the low level prototypes and macros for the
//!        Eeprom access for AT90CAN128/64/32 parts
//!
//! This template file can be parsed by Doxygen for automatic documentation
//! generation.
//!
//! Compiler: IAR C/C++ Compiler for AVR 4.12A/W32 (4.12.1.5)
//!
//! @version $Revision: 2.30 $ $Name: jtellier $
//!
//! @todo
//! @bug
//**************************************************************************

#ifndef _EEPROM_DRV_H_
#define _EEPROM_DRV_H_

//_____ I N C L U D E S ____________________________________________________
#include <intrinsics.h>

//_____ D E F I N I T I O N S ______________________________________________
#define     _EEPROM_TYPE_    __eeprom

#define     EEPROM_BYTE_AT   *(U8 _EEPROM_TYPE_*)
#define      SRAM_BYTE_AT    *(U8*)

#define     EEPROM_BLANK_BYTE    0xFF

//_____ M A C R O S ________________________________________________________

  //--- intrinsic Eeprom functions

  //--- Eeprom basic functions
#define     Eeprom_prog_completed       { while (EECR & (1<<EEWE)); }

  //--- Eeprom functions (c.f. intrinsic Eeprom functions)
#define     Eeprom_rd_byte(addr)        ( EEPROM_BYTE_AT(addr) )        //- "Eeprom_prog_completed" is done in intrinsics function
#define     Eeprom_wr_byte(addr, data)  ( EEPROM_BYTE_AT(addr) = data ) //- "Eeprom_prog_completed" is done in intrinsics function


//_____ D E C L A R A T I O N S ____________________________________________



//**************************************************************************

#endif // _EEPROM_DRV_H_

