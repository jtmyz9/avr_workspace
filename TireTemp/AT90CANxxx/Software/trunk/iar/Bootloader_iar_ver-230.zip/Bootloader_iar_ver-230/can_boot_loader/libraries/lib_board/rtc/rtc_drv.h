//***************************************************************************
//! @file $RCSfile: rtc_drv.h,v $
//!
//! Copyright (c) 2005 Atmel.
//!
//! Please read file license.txt for copyright notice.
//!
//! @brief RTC (Real Time Counter) include file.
//!
//! @version $Revision: 2.00 $ $Name: jtellier $ 
//!
//! @todo
//! @bug
//***************************************************************************

#ifndef _RTC_DRV_H_
#define _RTC_DRV_H_

//_____ I N C L U D E S ____________________________________________________

//_____ D E F I N I T I O N S ______________________________________________

#ifndef RTC_TIMER
#  error  You must define RTC_TIMER in "board.h" file
#endif
#ifndef RTC_CLOCK
#  error  You must define RTC_CLOCK in "config.h" file
#endif
	
//_____ M A C R O S ________________________________________________________

//_____ D E C L A R A T I O N S ____________________________________________

//_____ P R O T O T Y P E S ________________________________________________

extern void wait_for(U16 ms_count);

//***************************************************************************

#endif  // _RTC_DRV_H_
