//**************************************************************************
//! @file $RCSfile: config.h,v $
//!
//! Copyright (c) 2006 Atmel.
//!
//! Please read file license.txt for copyright notice.
//!
//! @brief Configuration file for this project.
//!
//! Compiler: IAR C/C++ Compiler for AVR 4.12A/W32 (4.12.1.5)
//!
//! @version $Revision: 2.30 $ $Name: jtellier $
//!
//! @todo
//! @bug
//**************************************************************************

#ifndef _CONFIG_H_
#define _CONFIG_H_

//_____ I N C L U D E S ____________________________________________________
#ifndef ENABLE_BIT_DEFINITIONS
#define  ENABLE_BIT_DEFINITIONS
#endif

#include <ioavr.h>
#include "compiler.h"
#include "at90can_drv.h"
#include "board.h"

//_____ D E F I N I T I O N S ______________________________________________

//---------------- BOOT LOADER DEFINITION ----------------
#define     BOOT_LOADER_SIZE            0x1000  // Size in bytes: 4KB
#define     MAX_FLASH_SIZE_TO_ERASE     ( FLASH_SIZE - ((U32)(BOOT_LOADER_SIZE)) )

//---------------- PROCESSOR DEFINITION ----------------
#define     MANUF_ID            0x1E        // ATMEL
#define     FAMILY_CODE         0x81        // AT90CANxxx family

#define     XRAM_END            XRAMEND     // Defined in "iocanxx.h"
#define     RAM_END             RAMEND      // Defined in "iocanxx.h"
#define     E2_END              E2END       // Defined in "iocanxx.h"
#define     FLASH_END           FLASHEND    // Defined in bytes in "iocanxx.h"
#define     FLASH_SIZE          ((U32)(FLASH_END)) + 1 // Size in bytes
#define     FLASH_PAGE_SIZE     256         // Size in bytes, constant for AT90CANxx devices

// Switches for specific definitions & switches
// Some specific definitions are defined across "io.h" i.e.e FLASHEND, E2END ...
#if   defined(__AT90CAN128__)               // __HAS_ELPM__ defined by IAR device selection
#   define  PRODUCT_NAME        0x97        // 128 Kbytes of Flash
#   define  PRODUCT_REV         0x00        // Rev 0
#   define  _BOOT_CONF_TYPE_    __farflash  // upper than 64K bytes
#   define  _RAMPZ_IS_USED_                 // RAMPZ register used if Flash memory upper than 64K bytes


#elif defined(__AT90CAN64__)                // __HAS_ELPM__ not-defined by IAR device selection
#   define  PRODUCT_NAME        0x96        // 64 Kbytes of Flash
#   define  PRODUCT_REV         0x00        // Rev 0
#   define  _BOOT_CONF_TYPE_    __flash     // lower than 64K bytes


#elif defined(__AT90CAN32__)                // __HAS_ELPM__ not-defined by IAR device selection
#   define  PRODUCT_NAME        0x95        // 32 Kbytes of Flash
#   define  PRODUCT_REV         0x00        // Rev 0
#   define  _BOOT_CONF_TYPE_    __flash     // lower than 64K bytes

#else
#   error Wrong device selection in IAR Embedded Workbench IDE "Project->Options ...->General Options->Target"
#endif

#define     FOSC                8000

//---------------- CAN DEFINITION -------------
//#define   CAN_BAUDRATE        500         // Baudrate in kBit
#define     CAN_BAUDRATE        CAN_AUTOBAUD

/*
//------------- STANDARD FLASH MEMORY DEFINITION ---------------
#define Enable_flash()
#define Disable_flash()

//------------- STANDARD EEPROM MEMORY DEFINITION -------------
#define Enable_eeprom()
#define Disable_eeprom()


//-------------- BOOTLOADER CONFIGURATION -------------
// Uart protocol
#define PROTOCOL_DATA                   64
#define GLOBAL_BUFFER_SIZE              PROTOCOL_DATA+4
#define NB_BYTE_MAX_FOR_DISPLAY_COMMAND 64
#define HEX_SIZE_DISP_PAGE              16
*/

//***************************************************************************

#endif  // _CONFIG_H_

